# PathKeep Audit Artifacts

This directory stores manifests, scheduler artifacts, and health reports. If Git is available, PathKeep may also keep a local commit history here.
